"use client";

import LogoutButton from "@/app/_utils/LogoutButton";
import PollList from "./PollList";
import CreatePollForm from "./CreatePollForm";

export default function ClientSideActions({ polls }: { polls: any[] }) {
    return (
        <div>
            {/* Logout button */}
            <LogoutButton />

            {/* Poll list */}
            <PollList polls={polls} />

            {/* Create poll form */}
            <CreatePollForm />
        </div>
    );
}
