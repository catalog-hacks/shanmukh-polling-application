"use client"

import {PasskeyList as CorbadoPasskeyList} from "@corbado/react";

export default function PasskeyList() {
    return (
        <CorbadoPasskeyList/>
    )
}